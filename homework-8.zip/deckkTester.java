public class deckkTester{
    public static void main(String[] args){
        Deck d = new Deck();
        System.out.println(d.getDeck());
        d.shuffle();
        System.out.println(d.getDeck());

    }
}