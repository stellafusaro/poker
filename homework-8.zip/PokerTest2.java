
public class PokerTest2 {

    //this class must remain unchanged
    //your code must work with this test class
 
    public static void main(String[] args){
        if (args.length<1){
            Game2 g = new Game2();
            g.play();
        }
        else{
            Game2 g = new Game2(args);
            g.play();
        }
    }

}
